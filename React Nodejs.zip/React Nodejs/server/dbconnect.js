const mysql = require("mysql2");
const db = mysql.createConnection({
    user: "root",
    host: "localhost",
    password: "aswin",
    database: "testdb",
});
module.exports = db;
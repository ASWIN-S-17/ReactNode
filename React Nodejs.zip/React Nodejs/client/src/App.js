import React, { useState } from 'react';
import axios from 'axios';

import './App.css';

const Login = () => {

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Handle login logic here
    const data = { "email": email, "password": password }
    await axios.post('http://localhost:3001/api/login', data)
    await axios.get('/api/login')
      .then(response => response.json())
      .then(data => {
        if (data.login === "true") {
          alert("Login Successfull")
        }
        else{
          alert("Wrong password")
        }
      });
    //

  };

  return (
    <div className="customback">
      <form onSubmit={handleSubmit}>
        <h2>Login</h2>
        <label htmlFor="email">Email:</label>
        <input
          type="email"
          id="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <label htmlFor="password">Password:</label>
        <input
          type="password"
          id="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <button type="submit">Login</button>
      </form>
    </div>
  );
};


const Signup = () => {
  const [companyname, setCompanyname] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  //console.log('signup');
  const handleSubmit = async (e) => {
    //e.preventDefault();
    // Handle signup logic here
    if (password !== confirmPassword) {
      alert("Please check password and confirm password!!!!")
      e.preventDefault();
    }
    else {
      try {
        const data = { "email": email, "companyname": companyname, "password": password }
        await axios.post('http://localhost:3001/api/create', data)
        alert("Signed Up Successfully")


      }
      catch (err) {
        alert('Error Axios')
      }




    }


  };

  return (
    <div className="customback">
      <form onSubmit={handleSubmit}>
        <h2>Signup</h2>
        <label htmlFor="companyname">Company Name</label>
        <input
          type="name"
          id="companyname"
          value={companyname}
          onChange={(e) => setCompanyname(e.target.value)}
          required
        />
        <label htmlFor="email">Email</label>
        <input
          type="email"
          id="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <label htmlFor="password">Password</label>
        <input
          type="password"
          id="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <label htmlFor="confirmPassword">Confirm Password</label>
        <input
          type="password"
          id="confirmPassword"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          required
        />
        <button type="submit">Signup</button>
      </form>
    </div>
  );
};

export default function App() {
  const [isLogin, setIsLogin] = useState(true);

  return (
    <div className="background">
    <div className="container">
      <button onClick={() => setIsLogin(!isLogin)}>
        {isLogin ? 'SignUp' : 'Login'}
      </button>
      {isLogin ? <Login /> : <Signup />}
    </div>
    </div>
  );
}


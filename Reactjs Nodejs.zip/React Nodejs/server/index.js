const express = require("express");
const app = express();
const mysql = require("mysql2");
const router = require("./routes")
var cors = require("cors")
const db = require("./dbconnect")
app.use(express.json());
app.use(cors());


/*app.get('/api',(req,res)=>{
    res.send('We are on home');
});*/
app.use('/api',router);















app.listen(3001, () => {
    db.connect((err) => {
        if (err) {
            console.error('Error connecting to MySQL database: ', err);
            return;
        }
        else{
            console.log("Connected to MySQL database")
        }
    });
    
    console.log("Server is listening on port 3000");
});
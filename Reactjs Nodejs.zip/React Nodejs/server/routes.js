const express = require('express');
const router = express.Router();
const axios = require('axios');
const db = require("./dbconnect")


//inserting values

router.post('/create', async (req, res) => {
    try {

        //  console.log(req.body);

        db.query('INSERT INTO users SET ?', req.body);
        console.log("Data Inserted Successfully");
        //await axios.post('http://localhost:3001/api/created',{"success":"true"})
        res.json({ message: "success" })

        console.log("Response Done");
    } catch (error) {
        console.error(error);
    }

});
//validation data from login
router.post('/login', async (req, res) => {
    try {
        var realpassword;
        var sql = 'SELECT password FROM users WHERE email = ?'
        db.query(sql, req.body.email, function (err, result) {
            if (err)
                throw err;
            console.log(result);
            if(!result){
                realpassword=null;
            }
            else{
                realpassword = result[0].password;
            }
            //console.log(result[0].password);
            //console.log(req.body.password);
            if(req.body.password !== realpassword)
            {   
                console.log("incorrect password");
                res.send(JSON.stringify({"status": 200, "error": null, "loginstatus": false}));
                //axios.post('http://localhost:3001/api/loginstatus',data)
        }
        else{
            console.log("Login Successfull");
            res.send(JSON.stringify({"status": 200, "error": null, "loginstatus": true}));
            //axios.post('http://localhost:3001/api/loginstatus',data)
        }
        });

       

    }
    catch (err) {
        res.json({ message: err });
    }

});

// post



module.exports = router